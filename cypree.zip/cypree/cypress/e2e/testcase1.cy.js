describe('Template spec', () => {
  it('Visiting Insight Software', () => {
    cy.visit('https://insightsoftware.com/bizview/');
	cy.wait(1000);
	cy.title('a.mega-menu-logo').should('include', 'software');
	//cy.get('img.mega-menu-logo.entered.lazyloaded').should('eq','insightsoftware');
	//cy.get('.learn-more-cta').click();
	//cy.navigate('Integrates with');
	//cy.get(".data-sources-close").click();
	//cy.get("https://insightsoftware.com/lawson/").click();
	/*cy.visit("oracle");
	cy.visit("Microsoft");
	cy.visit("SAP");
	cy.visit("Deltek");
	//when tab is changes, list changes*/
	
  })
  
  
})